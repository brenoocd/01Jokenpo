import React from 'react'
import ReactDOM from 'react-dom/client'
import Header from './components/Header/index'
import './index.css'
import Container from './components/Container'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <Header />
    <Container/>
  </React.StrictMode>,
)