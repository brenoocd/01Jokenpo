import styles from './Container.module.css'

function Container (){
    return (
        <>
        <button>Pedra</button>
        <button>Papel</button>
        <button>Tesoura</button>
        </>
        
    )
}
export default Container