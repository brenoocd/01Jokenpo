
import styles from './Header.module.css'

function Header() {
    return (
        <header className={styles.header}>
            <nav>
                <span>Pedra, Papel e Tesoura</span><br />
                <span>Placar : </span>
                    
            </nav>
        </header>
    )    
}

export default Header